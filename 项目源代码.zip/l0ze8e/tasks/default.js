import gulp from 'gulp';

gulp.task('default',['build']);
